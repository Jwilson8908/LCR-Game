#pragma once

#include "Player.h"
#include <vector>
#include <string>

using namespace std;

class LCRGame
{
private:
    vector<Player> players;
    int currentPlayer;
    int centerChips;

    int rollDie();
    char getDieResult(int dieRoll);

    void passLeft(int playerIndex);
    void passRight(int playerIndex);
    void passCenter(int playerIndex);

    bool hasWinner();
    int getWinner();

public:
    LCRGame();

    void setupGame();
    void playGame();
};