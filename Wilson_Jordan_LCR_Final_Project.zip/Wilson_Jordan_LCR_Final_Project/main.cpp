// main.cpp
// IT-312
// Final Project: Left Center Right (LCR)
//
// Code Description:
// This program displays the LCR game rules from a text file,
// creates the LCRGame object, sets up the players, and starts
// the game.
//
// Development Notes:
// The main function coordinates the program while the LCRGame
// and Player classes handle the game's functionality.

#include <iostream>
#include <fstream>
#include <string>
#include "LCRGame.h"

using namespace std;

int main()
{
    // Open the LCR rules text file.
    ifstream rulesFile("LCRRules.txt");

    // Display the rules before starting the game.
    if (rulesFile.is_open())
    {
        string line;

        cout << "========================================" << endl;
        cout << "        LEFT CENTER RIGHT (LCR)" << endl;
        cout << "========================================" << endl;
        cout << endl;

        cout << "GAME RULES" << endl;
        cout << "----------------------------------------" << endl;

        // Read and display each line from the rules file.
        while (getline(rulesFile, line))
        {
            cout << line << endl;
        }

        rulesFile.close();

        cout << endl;
        cout << "========================================" << endl;
        cout << endl;
    }
    else
    {
        // Display a warning if the rules file cannot be opened.
        cout << "Warning: LCRRules.txt could not be opened."
            << endl;

        cout << "The game will continue without displaying "
            << "the rules." << endl;

        cout << endl;
    }

    // Create the LCR game object.
    LCRGame game;

    // Set up the players.
    game.setupGame();

    // Start the LCR game.
    game.playGame();

    return 0;
}