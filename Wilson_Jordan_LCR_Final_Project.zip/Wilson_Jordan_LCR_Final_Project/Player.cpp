// Player.cpp
// This file contains the method definitions for the Player class.
// The Player class stores a player's name and current number of chips.
// Each player begins the LCR game with three chips.

#include "Player.h"

using namespace std;

// Constructor initializes the player's name and starting chip count.
Player::Player(string name)
{
    playerName = name;
    chips = 3;
}

// Returns the player's name.
string Player::getName()
{
    return playerName;
}

// Returns the player's current number of chips.
int Player::getChips()
{
    return chips;
}

// Adds one chip to the player's total.
// This is used when another player passes a chip to this player.
void Player::addChip()
{
    chips++;
}

// Removes one chip from the player's total.
// This is used when a player passes a chip or places one in the center.
void Player::removeChip()
{
    if (chips > 0)
    {
        chips--;
    }
}