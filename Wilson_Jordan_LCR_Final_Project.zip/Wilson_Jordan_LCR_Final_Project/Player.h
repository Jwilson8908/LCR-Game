#pragma once

#include <string>

using namespace std;

class Player
{
private:
    string playerName;
    int chips;

public:
    Player(string name);

    string getName();
    int getChips();

    void addChip();
    void removeChip();
};