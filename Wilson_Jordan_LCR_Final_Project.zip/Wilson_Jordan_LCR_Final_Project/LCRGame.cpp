// LCRGame.cpp
// IT-312
// Final Project: Left Center Right (LCR)
//
// Code Description:
// This file contains the game logic for the Left Center Right (LCR)
// game. The LCRGame class manages players, dice rolls, chip movement,
// turns, and determining the winner.
//
// Development Notes:
// The game was developed using object-oriented programming. The Player
// class manages individual player information and chip counts. The
// LCRGame class manages the overall game, including turns, dice,
// chip movement, and determining the winner.
//
// The program also uses an array to store the results of the dice rolled
// during each player's turn. A maximum of three dice can be rolled.
//
// Issues Encountered:
// One issue encountered during development was making sure the rules
// text file could be found when the program runs. The file was added
// to the project and configured as content so it can be available with
// the program's output files.

#include "LCRGame.h"
#include <iostream>
#include <cstdlib>
#include <ctime>
#include <limits>

using namespace std;

// Constructor initializes the game with no current player
// and an empty center pot.
LCRGame::LCRGame()
{
    currentPlayer = 0;
    centerChips = 0;

    // Seed the random number generator.
    srand(static_cast<unsigned int>(time(0)));
}

// Generates a random number from 1 through 6
// to represent one die roll.
int LCRGame::rollDie()
{
    return rand() % 6 + 1;
}

// Converts the randomly generated die number into
// an LCR result.
//
// 1 = Left
// 2 = Right
// 3 = Center
// 4-6 = Dot/No action
char LCRGame::getDieResult(int dieRoll)
{
    if (dieRoll == 1)
    {
        return 'L';
    }
    else if (dieRoll == 2)
    {
        return 'R';
    }
    else if (dieRoll == 3)
    {
        return 'C';
    }
    else
    {
        return '*';
    }
}

// Passes one chip from the current player
// to the player on the left.
void LCRGame::passLeft(int playerIndex)
{
    int leftPlayer =
        (playerIndex - 1 + players.size()) % players.size();

    players[playerIndex].removeChip();
    players[leftPlayer].addChip();
}

// Passes one chip from the current player
// to the player on the right.
void LCRGame::passRight(int playerIndex)
{
    int rightPlayer =
        (playerIndex + 1) % players.size();

    players[playerIndex].removeChip();
    players[rightPlayer].addChip();
}

// Moves one chip from the current player
// into the center pot.
void LCRGame::passCenter(int playerIndex)
{
    players[playerIndex].removeChip();
    centerChips++;
}

// Determines whether only one player
// still has chips.
bool LCRGame::hasWinner()
{
    int playersWithChips = 0;

    for (int playerIndex = 0;
        playerIndex < players.size();
        playerIndex++)
    {
        if (players[playerIndex].getChips() > 0)
        {
            playersWithChips++;
        }
    }

    return playersWithChips == 1;
}

// Finds and returns the index of the player
// who still has chips.
int LCRGame::getWinner()
{
    for (int playerIndex = 0;
        playerIndex < players.size();
        playerIndex++)
    {
        if (players[playerIndex].getChips() > 0)
        {
            return playerIndex;
        }
    }

    return -1;
}

// Sets up the game by asking the user for
// the number of players and each player's name.
void LCRGame::setupGame()
{
    int numberOfPlayers;

    cout << "Welcome to Left Center Right!" << endl;
    cout << endl;

    // Require at least three players.
    do
    {
        cout << "Enter the number of players (minimum 3): ";
        cin >> numberOfPlayers;

        if (numberOfPlayers < 3)
        {
            cout << "You need at least 3 players. "
                << "Please add more players." << endl;
        }

    } while (numberOfPlayers < 3);

    // Clear the newline left in the input buffer.
    cin.ignore(numeric_limits<streamsize>::max(), '\n');

    // Collect each player's name.
    for (int playerIndex = 0;
        playerIndex < numberOfPlayers;
        playerIndex++)
    {
        string playerName;

        cout << "Enter name for Player "
            << playerIndex + 1 << ": ";

        getline(cin, playerName);

        // Give the player a default name if
        // the user leaves the name blank.
        if (playerName.empty())
        {
            playerName =
                "Player " + to_string(playerIndex + 1);
        }

        players.push_back(Player(playerName));
    }

    cout << endl;
    cout << "All players start with 3 chips." << endl;
    cout << "Let the game begin!" << endl;
    cout << endl;
}

// Runs the main LCR game loop.
void LCRGame::playGame()
{
    // Continue playing until only one player
    // has chips remaining.
    while (!hasWinner())
    {
        // Players with zero chips remain in the game,
        // but they do not roll until they receive chips.
        if (players[currentPlayer].getChips() == 0)
        {
            currentPlayer =
                (currentPlayer + 1) % players.size();

            continue;
        }

        int chips =
            players[currentPlayer].getChips();

        int diceToRoll = chips;

        // A player can roll a maximum of three dice.
        if (diceToRoll > 3)
        {
            diceToRoll = 3;
        }

        cout << "----------------------------------------"
            << endl;

        cout << players[currentPlayer].getName()
            << "'s turn" << endl;

        cout << "Chips: "
            << chips << endl;

        cout << "Rolling "
            << diceToRoll
            << " dice." << endl;

        cout << endl;

        // Array stores the results of the dice
        // rolled during the current player's turn.
        // The maximum number of dice is three.
        char diceResults[3];

        // Roll the required number of dice.
        for (int dieIndex = 0;
            dieIndex < diceToRoll;
            dieIndex++)
        {
            diceResults[dieIndex] =
                getDieResult(rollDie());

            cout << "Die "
                << dieIndex + 1
                << ": "
                << diceResults[dieIndex]
                << endl;

            // Process the result of the die.
            if (diceResults[dieIndex] == 'L')
            {
                passLeft(currentPlayer);
            }
            else if (diceResults[dieIndex] == 'R')
            {
                passRight(currentPlayer);
            }
            else if (diceResults[dieIndex] == 'C')
            {
                passCenter(currentPlayer);
            }
            // '*' requires no action.
        }

        cout << endl;

        // Display the current chip count
        // for every player.
        cout << "Chip counts:" << endl;

        for (int playerIndex = 0;
            playerIndex < players.size();
            playerIndex++)
        {
            cout << players[playerIndex].getName()
                << ": "
                << players[playerIndex].getChips()
                << " chips"
                << endl;
        }

        cout << "Center pot: "
            << centerChips
            << " chips"
            << endl;

        cout << endl;

        // Move to the next player if the game
        // has not ended.
        if (!hasWinner())
        {
            currentPlayer =
                (currentPlayer + 1) % players.size();
        }
    }

    // Determine the winner.
    int winner = getWinner();

    cout << "========================================"
        << endl;

    cout << "The winner is "
        << players[winner].getName()
        << "!"
        << endl;

    cout << "Congratulations!"
        << endl;

    cout << "========================================"
        << endl;
}